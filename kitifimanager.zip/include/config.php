<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<admin','mikhmon>|>rJ2dq5mWaWpqcA==');


$data['Juanfi'] = array ('1'=>'Juanfi!192.168.10.1','Juanfi@|@admin','Juanfi#|#rJ2dq5mWaWpqcKOXm6ConaM=','Juanfi%KiTricks','Juanfi^10.0.0.1','Juanfi&Php','Juanfi*10','Juanfi(1','Juanfi)','Juanfi=10','Juanfi@!@disable');